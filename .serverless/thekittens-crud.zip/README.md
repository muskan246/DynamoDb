steps to run:
awseducate.com
https://labs.vocareum.com/main/main.php?m=editor&nav=1&asnid=14334&stepid=14335
account details : copy 
paste in .aws/credentials

Configure:
serverless config credentials --provider aws --key AKIAIOSFODNN7EXAMPLE --secret wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY

serverless deploy --stage dev

serverless config credentials --provider aws --key ASIAWRBIF4KBPI2SOCYH --secret H1YgdDWQ/OEiKAgasOeaBbwj2feVxQc2zkdI8ouQ